
  # Modern Dark-Mode Portfolio

  This is a code bundle for Modern Dark-Mode Portfolio. The original project is available at https://www.figma.com/design/Zc1iIBCDTxstTlXLdPfNie/Modern-Dark-Mode-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  