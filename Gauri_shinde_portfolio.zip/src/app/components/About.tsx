import { MapPin, Target, Lightbulb } from 'lucide-react';
import { motion } from 'motion/react';

export function About() {
  const personalCards = [
    { icon: MapPin, label: 'Based in', value: 'Pune, India' },
    { icon: Target, label: 'Open to', value: 'Internships & Opportunities' },
    { icon: Lightbulb, label: 'Focus', value: 'GenAI & Data Science' },
  ];

  const timeline = [
    { year: '2025–Present', title: 'M.Sc Data Science' },
    { year: '2025', title: 'Completed B.Sc Data Science' },
    { year: '2024–2025', title: 'Data & Software Development Internship' },
    { year: 'Current', title: 'Exploring GenAI and AI product workflows' },
  ];

  return (
    <section id="about" className="py-32 px-6 lg:px-12 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-sm text-white/40 uppercase tracking-wider mb-4"
        >
          About
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left Column - Story */}
          <div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-medium mb-8 leading-tight"
            >
              Building practical AI and data-driven experiences.
            </motion.h2>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="space-y-6 text-lg text-white/60 mb-12"
            >
              <p>
                I enjoy transforming ideas into working solutions using data, AI, and modern development workflows. My interests span analytics, machine learning, and creating products that are useful and intuitive.
              </p>
              <p>
                Through projects and internship experience, I've worked across dashboards, predictive models, and AI-driven applications while continuously exploring emerging technologies.
              </p>
            </motion.div>

            {/* Personal Cards */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="grid grid-cols-1 sm:grid-cols-3 gap-4"
            >
              {personalCards.map((card, index) => (
                <div
                  key={index}
                  className="p-6 rounded-3xl bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300"
                >
                  <card.icon size={20} className="text-purple-400 mb-3" />
                  <div className="text-xs text-white/40 mb-1">{card.label}</div>
                  <div className="text-sm text-white/90">{card.value}</div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right Column - Timeline */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="relative"
          >
            <div className="lg:sticky lg:top-32">
              <div className="p-8 lg:p-10 rounded-[32px] bg-white/5 backdrop-blur-sm border border-white/10">
                <h3 className="text-2xl font-medium mb-8">Journey</h3>
                <div className="space-y-8">
                  {timeline.map((item, index) => (
                    <div key={index} className="flex gap-6 group">
                      {/* Timeline dot and line */}
                      <div className="flex flex-col items-center">
                        <div className="w-3 h-3 rounded-full bg-purple-400 ring-4 ring-purple-400/20 group-hover:ring-8 transition-all duration-300" />
                        {index < timeline.length - 1 && (
                          <div className="w-[2px] h-full bg-white/10 mt-2" />
                        )}
                      </div>
                      {/* Content */}
                      <div className="flex-1 pb-2">
                        <div className="text-sm text-purple-400 mb-1">
                          {item.year}
                        </div>
                        <div className="text-base text-white/90">
                          {item.title}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
