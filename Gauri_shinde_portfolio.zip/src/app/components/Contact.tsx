import { Mail, Linkedin, Github, MapPin, ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';

export function Contact() {
  const contactItems = [
    {
      icon: Mail,
      label: 'Email',
      value: 'your.email@example.com',
      href: 'mailto:your.email@example.com',
    },
    {
      icon: Linkedin,
      label: 'LinkedIn',
      value: 'linkedin.com/in/gaurishinde',
      href: 'https://linkedin.com',
    },
    {
      icon: Github,
      label: 'GitHub',
      value: 'github.com/gaurishinde',
      href: 'https://github.com',
    },
    {
      icon: MapPin,
      label: 'Location',
      value: 'Pune, India',
      href: null,
    },
  ];

  return (
    <section id="contact" className="py-32 px-6 lg:px-12 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-sm text-white/40 uppercase tracking-wider mb-4"
        >
          Contact
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column - Heading */}
          <div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-medium mb-6 leading-tight"
            >
              Let's build data-driven things.
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-white/60 max-w-xl"
            >
              Open to internships, collaboration opportunities, and conversations around AI, data, and technology.
            </motion.p>
          </div>

          {/* Right Column - Contact Panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="p-8 lg:p-10 rounded-[32px] bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-sm border border-white/10"
          >
            <div className="space-y-6">
              {contactItems.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: 0.4 + 0.1 * index }}
                >
                  {item.href ? (
                    <a
                      href={item.href}
                      target={item.icon !== Mail ? '_blank' : undefined}
                      rel={item.icon !== Mail ? 'noopener noreferrer' : undefined}
                      className="group flex items-center gap-4 p-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all duration-300"
                    >
                      <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                        <item.icon size={20} className="text-purple-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-white/40 mb-1">{item.label}</div>
                        <div className="text-sm text-white/90 truncate">{item.value}</div>
                      </div>
                      <ArrowUpRight
                        size={18}
                        className="text-white/40 group-hover:text-white group-hover:translate-x-1 group-hover:-translate-y-1 transition-all duration-300 flex-shrink-0"
                      />
                    </a>
                  ) : (
                    <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/10">
                      <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                        <item.icon size={20} className="text-purple-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-white/40 mb-1">{item.label}</div>
                        <div className="text-sm text-white/90">{item.value}</div>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
