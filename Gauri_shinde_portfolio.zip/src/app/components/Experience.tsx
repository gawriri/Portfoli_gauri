import { Briefcase, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export function Experience() {
  const highlights = [
    'Worked on data-driven solutions and development tasks.',
    'Contributed to project implementation and workflow improvements.',
    'Built practical experience across analytics and software environments.',
  ];

  return (
    <section id="experience" className="py-32 px-6 lg:px-12 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-sm text-white/40 uppercase tracking-wider mb-4"
        >
          Experience
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-medium mb-16 max-w-3xl leading-tight"
        >
          Professional journey
        </motion.h2>

        {/* Experience Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="relative p-8 lg:p-12 rounded-[32px] bg-gradient-to-br from-white/5 to-white/[0.02] backdrop-blur-sm border border-white/10 overflow-hidden group hover:border-white/20 transition-all duration-300"
        >
          {/* Background gradient on hover */}
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

          <div className="relative">
            {/* Icon */}
            <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-6">
              <Briefcase size={28} className="text-purple-400" />
            </div>

            {/* Role and Organization */}
            <div className="mb-6">
              <h3 className="text-2xl sm:text-3xl font-medium mb-2">
                Data & Software Development Intern
              </h3>
              <div className="flex flex-wrap items-center gap-3 text-white/60">
                <span className="text-lg">Golden Bird Education</span>
                <span className="w-1 h-1 rounded-full bg-white/40" />
                <span className="text-sm">Dec 2024 – May 2025</span>
              </div>
            </div>

            {/* Highlights */}
            <div className="space-y-4">
              {highlights.map((highlight, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: 0.3 + 0.1 * index }}
                  className="flex gap-3"
                >
                  <CheckCircle2
                    size={20}
                    className="text-cyan-400 mt-0.5 flex-shrink-0"
                  />
                  <p className="text-base text-white/70">{highlight}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
