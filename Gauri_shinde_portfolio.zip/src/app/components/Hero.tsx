import { ArrowRight, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

export function Hero() {
  const stats = [
    { label: 'Projects', value: '3+' },
    { label: 'Internship', value: '1' },
    { label: 'M.Sc Data Science', value: '' },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 px-6 lg:px-12">
      <div className="max-w-7xl mx-auto w-full">
        <div className="flex flex-col items-center text-center">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 mb-8"
          >
            <span className="text-xs sm:text-sm text-white/70 tracking-wider uppercase">
              GENAI • DATA SCIENCE • AI APPLICATIONS
            </span>
          </motion.div>

          {/* Main Heading */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="mb-6"
          >
            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-medium mb-4 tracking-tight">
              Hi, I'm
            </h1>
            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-medium bg-gradient-to-r from-white via-purple-200 to-cyan-200 bg-clip-text text-transparent tracking-tight">
              Gauri Shinde
            </h1>
          </motion.div>

          {/* Subheading */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl sm:text-2xl text-white/60 mb-6"
          >
            GenAI Intern • Data Science Graduate
          </motion.p>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-base sm:text-lg text-white/50 max-w-2xl mb-12"
          >
            Building AI-powered applications, analytics dashboards, and data-driven solutions through experimentation, learning, and practical implementation.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 mb-16"
          >
            <a
              href="#projects"
              className="group px-8 py-4 bg-white text-black rounded-3xl hover:bg-white/90 transition-all duration-300 flex items-center gap-2 font-medium"
            >
              View Projects
              <ArrowRight
                size={18}
                className="group-hover:translate-x-1 transition-transform duration-300"
              />
            </a>
            <a
              href="#contact"
              className="px-8 py-4 bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl hover:bg-white/10 transition-all duration-300 font-medium"
            >
              Contact Me
            </a>
          </motion.div>

          {/* Stats Cards */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-3xl mb-12"
          >
            {stats.map((stat, index) => (
              <div
                key={index}
                className="p-6 rounded-3xl bg-white/5 backdrop-blur-sm border border-white/10"
              >
                {stat.value && (
                  <div className="text-3xl font-medium mb-1">{stat.value}</div>
                )}
                <div className="text-sm text-white/60">{stat.label}</div>
              </div>
            ))}
          </motion.div>

          {/* Status Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="relative overflow-hidden p-6 rounded-[32px] bg-gradient-to-br from-purple-500/10 to-cyan-500/10 backdrop-blur-sm border border-white/10 max-w-md"
          >
            <div className="absolute top-4 right-4">
              <Sparkles size={20} className="text-purple-400" />
            </div>
            <div className="text-sm text-white/60 mb-2">Currently Exploring</div>
            <div className="text-base text-white/90">
              Generative AI • LLM Workflows • AI Product Building
            </div>
          </motion.div>

          {/* Gradient Orb */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-purple-600/20 to-cyan-600/20 rounded-full blur-[150px] -z-10" />
        </div>
      </div>
    </section>
  );
}
