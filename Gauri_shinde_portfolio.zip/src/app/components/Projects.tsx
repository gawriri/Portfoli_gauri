import { ArrowUpRight, Sparkles, BarChart3, Brain } from 'lucide-react';
import { motion } from 'motion/react';

export function Projects() {
  const projects = [
    {
      icon: Sparkles,
      title: 'SnapLearn AI',
      description: 'AI-powered educational workflow concept.',
      stack: ['Python', 'AI', 'Analytics'],
      gradient: 'from-purple-500/20 to-pink-500/20',
    },
    {
      icon: BarChart3,
      title: 'Crop Production Dashboard',
      description: 'Interactive dashboard for production insights.',
      stack: ['Power BI', 'Data Visualization'],
      gradient: 'from-cyan-500/20 to-blue-500/20',
    },
    {
      icon: Brain,
      title: 'Procrastination Prediction',
      description: 'Predictive analytics project using machine learning.',
      stack: ['Python', 'ML', 'Data Science'],
      gradient: 'from-violet-500/20 to-purple-500/20',
    },
  ];

  return (
    <section id="projects" className="py-32 px-6 lg:px-12 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-sm text-white/40 uppercase tracking-wider mb-4"
        >
          Projects
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-medium mb-16 max-w-3xl leading-tight"
        >
          Featured work and experiments
        </motion.h2>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              className={`group relative p-8 rounded-[32px] bg-gradient-to-br ${project.gradient} backdrop-blur-sm border border-white/10 hover:border-white/20 transition-all duration-300 cursor-pointer overflow-hidden`}
            >
              {/* Hover gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="relative">
                {/* Icon */}
                <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <project.icon size={24} className="text-white" />
                </div>

                {/* Title */}
                <h3 className="text-xl sm:text-2xl font-medium mb-3 flex items-start justify-between">
                  {project.title}
                  <ArrowUpRight
                    size={20}
                    className="text-white/40 group-hover:text-white group-hover:translate-x-1 group-hover:-translate-y-1 transition-all duration-300"
                  />
                </h3>

                {/* Description */}
                <p className="text-white/60 mb-6 text-base">{project.description}</p>

                {/* Stack */}
                <div className="flex flex-wrap gap-2">
                  {project.stack.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm border border-white/10 text-xs text-white/70"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
