import { Code2, BarChart3, Brain, Database } from 'lucide-react';
import { motion } from 'motion/react';

export function Skills() {
  const skillCategories = [
    {
      icon: Code2,
      title: 'Programming',
      skills: ['Python', 'SQL'],
      gradient: 'from-blue-500/20 to-cyan-500/20',
    },
    {
      icon: BarChart3,
      title: 'Data Analytics',
      skills: ['Pandas', 'NumPy', 'Power BI', 'Excel', 'Matplotlib'],
      gradient: 'from-purple-500/20 to-pink-500/20',
    },
    {
      icon: Brain,
      title: 'Machine Learning',
      skills: [
        'Classification',
        'Decision Trees',
        'Logistic Regression',
        'Feature Engineering',
        'NLP',
      ],
      gradient: 'from-violet-500/20 to-purple-500/20',
    },
    {
      icon: Database,
      title: 'Data Skills',
      skills: [
        'Data Cleaning',
        'Data Visualization',
        'EDA',
        'Statistical Analysis',
      ],
      gradient: 'from-cyan-500/20 to-teal-500/20',
    },
  ];

  return (
    <section id="skills" className="py-32 px-6 lg:px-12 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-sm text-white/40 uppercase tracking-wider mb-4"
        >
          Skills
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-medium mb-16 max-w-3xl leading-tight"
        >
          Technical expertise and tools
        </motion.h2>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {skillCategories.map((category, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              className={`group p-8 rounded-[32px] bg-gradient-to-br ${category.gradient} backdrop-blur-sm border border-white/10 hover:border-white/20 transition-all duration-300`}
            >
              {/* Icon */}
              <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <category.icon size={24} className="text-white" />
              </div>

              {/* Title */}
              <h3 className="text-2xl font-medium mb-6">{category.title}</h3>

              {/* Skills Tags */}
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill, skillIndex) => (
                  <motion.span
                    key={skillIndex}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{
                      duration: 0.3,
                      delay: 0.1 * index + 0.05 * skillIndex,
                    }}
                    whileHover={{ scale: 1.05 }}
                    className="px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/10 text-sm text-white/80 hover:bg-white/20 hover:text-white transition-all duration-300 cursor-default"
                  >
                    {skill}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
